from prompt_toolkit import prompt
from re import *
from turtle import *
from time import *  
from random import *

def main():
  question = input("Желаете зарегистрироваться? Или уже есть аккаунт? (войти , зарег): ").lower()
  while True:
    if question == "войти":
      with open("names.txt","r",encoding="utf-8") as f:
        result = list(f.read())
        if result == []:
          print("Нету активных аккаунтов! Вам нужно зарегистрироваться!")
          registration()
        else:
          login()
    elif question == "зарег":
      registration()
    else:
      print("Непонятный запрос")
    question = input("Желаете зарегистрироваться? Или уже есть аккаунт? (войти , зарег): ").lower()

def registration():
  name = input("Введите имя: ")
  password = input("Введите пароль: ")
  while True:
    with open("names.txt","r") as f:
      content = f.read()
    content = findall(r"\w+(?=-)",content)   
    for i in content:
      if i == name:
        print("Эта имя пользователя уже занято!")
        break
    else:      
      if len(password) >= 5:
        if fullmatch(r"[A-Za-z0-9]+", password):
          print(f"Добро пожаловать {name}!")
          with open("names.txt","a",encoding="utf-8") as f:
            f.write(f"{name}-{str(password)}\n")
          quiz()
        else:
          print("Недопустимый пароль!")
      else:
        print("Слишком короткая длина пароля!")

    name = input("Введите имя: ")
    password = input("Введите пароль: ")
    

def login():
  name = input("Введите имя: ")
  password = input("Введите пароль: ")
  while True:
    with open("names.txt","r",encoding="utf-8") as f:
      content = f.read()
    pattern = rf"\b{name}\b-\b{password}\b"
    result = search(pattern,content)
    if result:
      print(f"Добро пожаловать {name}!")
      quiz()
      break
    else:
      print("Неверное имя или пароль!")
    name = input("Введите имя: ")
    password = input("Введите пароль: ")
 

def quiz():
  ask_command = input("Что будем делать?(создать, играть, заметки): ")
  while True:
    if ask_command == "создать":
      create_quiz()
    elif ask_command == "играть":
      play_quiz()
    elif ask_command == "заметки":
      notes()
    else:
      print("Непонятный запрос")
    ask_command = input("Что будем делать?(создать, играть, заметки): ")

def create_quiz():
  ask_question = input("Введите любой вопрос для карточки: ")
  ask_answer = input("А теперь ответ для этой карточки: ")
  with open("questions.txt","a",encoding="utf-8") as f:
    f.write(f"{ask_question}:{ask_answer}\n")

def play_quiz():
  count = 0
  ht()
  with open("questions.txt","r",encoding="utf-8") as f:
    content = f.read()
  questions = findall(r".+?(?=:)",content)
  while True:
    randomq = choice(questions)
    print(randomq)
    start = time()
    answer = input("Ваш ответ(exit - выйти): ")
    result = search(rf"^{escape(randomq)}\s*:\s*{escape(answer)}$",content,flags=MULTILINE | IGNORECASE)
    if answer == "exit":
      bye()
      return
    elif result:
      end = time()
      if round(end) - round(start) > 30:
        print("Время истекло...")
      else:
        count += 1   
        print(f"Правильно! Ваш счетчик составляет уже {count} угаданных!")
        clear()
        color("green")
        pensize(20)
        right(60)
        forward(90)
        left(100)
        forward(200)
        right(40)
        draw(0,0)
        start = time()
    else:
      print("Неправильно...")
      clear()
      color("red")
      pensize(20)
      draw(-200,-200)
      left(40)
      forward(400)
      draw(100,-200)
      left(100)
      forward(400)
      right(140)
      draw(0,0)
      start = time()


def draw(x,y):
  penup()
  goto(x,y)
  pendown()

def notes():
  movement = input("Что хотите делать с заметками (прочитать, редактировать, exit):")
  while True:
    if movement == "exit":
      return
    elif movement == "прочитать":
      with open("notes.txt",'r',encoding="utf-8") as f:
        content = f.read()
      print(content)
    elif movement == "редактировать":
      print("Нажмите Esc и потом Enter чтобы закончить редактировать")
      with open("notes.txt",'r',encoding="utf-8") as f:
        content = f.read()
      text = prompt(default=f"{content}", multiline=True)
      with open("notes.txt",'w',encoding="utf-8") as f:
        f.write(text)
    else:
      print("Несуществующий запрос")
    movement = input("Что хотите делать с заметками (прочитать, редактировать, exit):")

main()